Swiss Pairing Tournament Project: Version 1.0 - 6.28.16

Motivation: 
-----------
This was created to complete Stage 5 "Choose Your Path" of the Intro
to Programming NanoDegree provided by Udacity.com!
--------------------------------------------------------------------

General Usage Notes 
--------------------
- The code in the tournament files (.sql & .py) illustrates how to create 
a Tournament utilizing Swiss Pairing principles.

- PostgreSQL is the database utilized

- tournament.sql contains the database schema

- tournament.py contains the functions, using a variety of sql and python
processes, that gather, sort, and return the data inputed.

- The file tournament_test.py is included so if you chose to 
modify the code you can run tests as you code to see if your changes
still allow the program to run.
-----------------------------------------------

Running:
---------------------------
- I utilized Vagrant and Git Bash to create the program in a virtual machine.

- The files were manipulated in Sublime, but any text editor that supports
python and sql would do.

- tournament_test.py can be run from Git Bash once the virtual machine
 is established and you have accessed the tournament directory using the
command python tournament_test.py

- This is a link to directions on how to install vagrant & utilize pre-
configured files, and further understand the files, the virtual machine,
psql commands, and a few tips on how to create the program:
  https://docs.google.com/document/d/16IgOm4XprTaKxAa8w02y028oBECOoB1EI1ReddADEeY/pub?embedded=true
------------------------------------------------

Special Thank You to:
---------------------
1. Udacity for the amazing curriculum
2. The Coaches for all their help
3. The contributors on the discussion forums that helped create a "class" like concept
 




