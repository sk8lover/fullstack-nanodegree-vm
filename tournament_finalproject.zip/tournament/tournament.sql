-- Table definitions for the tournament project.
--
-- Put your SQL 'create table' statements in this file; also 'create view'
-- statements if you choose to use it.
--
-- You can write comments in this file by starting them with two dashes, like
-- these lines here.

-- Creating & Re-creating for ease of programming
drop database if exists tournament;
create database tournament;
\c tournament;


-- Creating Players table: Needed to uniquely ID each player
-- & I wanted a full name entered rather than first or last.
-- Added not null because even though a name isn't unique
-- it was a detail I always wanted to have!
create table players ( ID serial PRIMARY KEY, FullName text not null);

-- Creating table tournaments:
create table tournaments ( id serial, name text NOT NULL);

-- Creating Matches table: I wanted to have a column for each match, 
-- tournament, winner, & loser's unique ID. 
create table Matches ( ID serial PRIMARY KEY, winner integer references players(ID)
	, loser integer references players(ID));

