#!/usr/bin/env python
# 
# tournament.py -- implementation of a Swiss-system tournament
#

import psycopg2


def connect():
    """Connect to the PostgreSQL database.  Returns a database connection."""
    """conn = psycopg2.connect(database='tournament', user='vagrant', password='vagrant')"""
    return psycopg2.connect("dbname=tournament")


def deleteMatches():
    DB = connect()
    c = DB.cursor()
    c.execute("delete from matches")
    DB.commit()
    DB.close()


def deletePlayers():
    """Remove all the player records from the database."""
    DB = connect()
    c = DB.cursor()
    c.execute("delete from players")
    DB.commit()
    DB.close()

def deleteTournaments():
    DB = connect()
    c = DB.cursor()
    c.execute("delete from tournaments")
    DB.commit()
    DB.close()

def deleteScoreboard():
    DB = connect()
    c = DB.cursor()
    c.execute("Delete from scoreboard")
    DB.commit()
    DB.close()

def createTournament(name):
    """ This function creates a tournament and
    requires the creator to name it. It also generates & returns
    the tournament ID number"""
    DB = connect()
    c = DB.cursor()
    sql = "insert into tournaments (name) VALUES (%s) returning id"
    c.execute(sql, (name,))
    tournamentid = c.fetchone()[0]
    DB.commit()
    DB.close()
    return tournamentid


def countPlayers():
    """Returns the number of players currently registered & 
    utilizes the tournamentID created in the above function."""
    DB = connect()
    c = DB.cursor()
    c.execute("select count(*) from players")
    results = c.fetchone()[0]
    DB.commit()
    DB.close()
    return results



def registerPlayer(name):
    """Adds a player to the tournament database.
  
    The database assigns a unique serial id number for the player.  (This
    should be handled by your SQL database schema, not in your Python code.)
  
    Args:
      name: the player's full name (need not be unique).
    """
    DB = connect()
    c = DB.cursor()
    c.execute("INSERT into players (FullName) VALUES (%s)", (name,))
    DB.commit()
    DB.close()


def playerStandings():
    """Returns a list of the players and their win records, sorted by wins.

    The first entry in the list should be the player in first place, or a player
    tied for first place if there is currently a tie.

    Returns:
      A list of tuples, each of which contains (id, name, wins, matches):
        id: the player's unique id (assigned by the database)
        name: the player's full name (as registered)
        wins: the number of matches the player has won
        matches: the number of matches the player has played
    """
    DB = connect()
    c = DB.cursor()
    c.execute( "select players.ID, players.FullName,"
        "count((select matches.winner from matches where matches.winner = players.ID)) as win,"
        "count(matches.winner) as games from players left join matches on "
        "players.ID = matches.winner or players.ID = matches.loser group by players.ID ")
    results = c.fetchall()
    sorted_by_wins = sorted(results, key = lambda tup: tup[2])
    DB.close()
    return sorted_by_wins



def reportMatch(winner, loser):
    """Records the outcome of a single match between two players.

    Args:
      winner:  the id number of the player who won
      loser:  the id number of the player who lost
    """
    DB = connect()
    c = DB.cursor()
    c.execute("INSERT INTO matches (winner, loser) VALUES ((%s), (%s))", (winner, loser))
    DB.commit()
    DB.close()

def swissPairings():
    """Returns a list of pairs of players for the next round of a match.
  
    Assuming that there are an even number of players registered, each player
    appears exactly once in the pairings.  Each player is paired with another
    player with an equal or nearly-equal win record, that is, a player adjacent
    to him or her in the standings.
  
    Returns:
      A list of tuples, each of which contains (id1, name1, id2, name2)
        id1: the first player's unique id
        name1: the first player's name
        id2: the second player's unique id
        name2: the second player's name
    """
    DB = connect()
    c = DB.cursor()
    Standings = playerStandings()
    print playerStandings()
    index = 0
    PlayerPairings = []
    while index < len(Standings):
        player1 = Standings[index]
        player2 = Standings[index+1]
        match = (player1[0], player1[1], player2[0], player2[1])
        PlayerPairings.append(match)
        index = index + 2

    # c.execute("create view Pairings as "
    #     "select players.ID as ID, players.FullName, "
    #     "count( (select matches.winner from matches where matches.winner = players.ID) ) as win,"
    #     "count(matches.winner) as games from players left join matches on "
    #     "players.ID = matches.winner or players.ID = matches.loser group by players.ID")
    # DB.commit()
    # c.execute("select Pairings_1.ID, Pairings_1.FullName, Pairings_2.ID, Pairings_2.FullName "
    #           "from Pairings as Pairings_1, Pairings as Pairings_2 "
    #           "where Pairings_1.win = Pairings_2.win and Pairings_1.ID > Pairings_2.ID")
    # Pairings = c.fetchall()
    # c.execute("drop view Pairings")
    DB.commit()
    DB.close()
    print PlayerPairings
    return PlayerPairings